UNKNOWN_ERROR = "Unknown Error"

NO_ACCOUNT = "No Account"

MESSAGE_TOO_LONG = "Message Too Long"

GAME_ALREADY_EXISTS = "Game Already Exists"
GAME_NOT_FOUND = "Game Not Found"
GAME_RETRIEVAL_ERROR = "Game Retrieval Error"
GAME_AMBIGUOUS = "Game Ambiguous"

USER_ALREADY_EXISTS = "User Already Exists"
